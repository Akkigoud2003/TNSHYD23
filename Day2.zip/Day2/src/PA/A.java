package PA;

public class A {
	public void display()
	{
		System.out.println("Hello world");
	}

}
