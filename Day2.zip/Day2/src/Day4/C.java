package Day4;

public class C {
	int a=10;
	static int b=20;
	int display() {
		return 10;
	}
		static void display1() {
			System.out.println(10);
		}
}
