package Day4;

public class D {
	public static void main(String[] args) {
		C c1=new C();
		System.out.println(c1.a);
		c1.display();
		System.out.println(C.b);
		C.display1();
		
	}
			
}


