package p13;
	import p12.*;
	public class Day6 extends Day5
	{
		public static void main(String[] args) {
			Day6 obj=new Day6();
					obj.display();
		}

}
