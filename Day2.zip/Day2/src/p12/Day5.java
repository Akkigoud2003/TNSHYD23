package p12;

public class Day5 {
	protected void display() {
		System.out.println("TNS session");
	
	}

}
