package p11;

public class MyClass1 {
	void display() {
		 System.out.println("TNS session");
	 }
	}

