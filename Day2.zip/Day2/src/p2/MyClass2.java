package p2;

public class MyClass2 {
public static void main(String[] args) {
	Myclass1 obj=new Myclass1();
	obj.display();
}
}
